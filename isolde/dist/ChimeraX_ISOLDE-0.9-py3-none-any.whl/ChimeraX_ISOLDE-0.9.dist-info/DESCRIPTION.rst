
ISOLDE is an ChimeraX interface to Interactive Molecular Dynamics
Flexible Fitting, or iMDFF.


