Sample code for implementing ChimeraX bundle.

Implements command "sample count" to report number of atoms and bonds.

